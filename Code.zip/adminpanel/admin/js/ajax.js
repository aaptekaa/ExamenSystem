// Админский вход
$(document).on("submit","#adminLoginFrm", function(){
   $.post("query/loginExe.php", $(this).serialize(), function(data){
      if(data.res == "invalid")
      {
        Swal.fire(
          'Ошибка!',
          'Введите действительное имя пользователя / пароль',
          'error'
        )
      }
      else if(data.res == "success")
      {
        $('body').fadeOut();
        window.location.href='home.php';
      }
   },'json');

   return false;
});



// Создание группы
$(document).on("submit","#addCourseFrm" , function(){
  $.post("query/addCourseExe.php", $(this).serialize() , function(data){
  	if(data.res == "exist")
  	{
  		Swal.fire(
  			'Already Exist',
  			data.course_name.toUpperCase() + ' Already Exist',
  			'error'
  		)
  	}
  	else if(data.res == "success")
  	{
  		Swal.fire(
  			'Готово!',
  			data.course_name.toUpperCase() + ' Группа Успешно Создана',
  			'success'
  		)
          // $('#course_name').val("");
          refreshDiv();
            setTimeout(function(){ 
                $('#body').load(document.URL);
             }, 2000);
  	}
  },'json')
  return false;
});

// Обновление группы
$(document).on("submit","#updateCourseFrm" , function(){
  $.post("query/updateCourseExe.php", $(this).serialize() , function(data){
     if(data.res == "success")
     {
        Swal.fire(
            'Готово!',
            'Выбранная группа была успешно обновлен!',
            'success'
          )
          refreshDiv();
     }
  },'json')
  return false;
});


// Удаление группы
$(document).on("click", "#deleteCourse", function(e){
    e.preventDefault();
    var id = $(this).data("id");
     $.ajax({
      type : "post",
      url : "query/deleteCourseExe.php",
      dataType : "json",  
      data : {id:id},
      cache : false,
      success : function(data){
        if(data.res == "success")
        {
          Swal.fire(
            'Готово!',
            'Выбранная Группа Удалена',
            'success'
          )
          refreshDiv();
        }
      },
      error : function(xhr, ErrorStatus, error){
        console.log(status.error);
      }

    });
    
   

    return false;
  });


// удаление теста
$(document).on("click", "#deleteExam", function(e){
    e.preventDefault();
    var id = $(this).data("id");
     $.ajax({
      type : "post",
      url : "query/deleteExamExe.php",
      dataType : "json",  
      data : {id:id},
      cache : false,
      success : function(data){
        if(data.res == "success")
        {
          Swal.fire(
            'Готово!',
            'Выбранная Группа Удалена',
            'success'
          )
          refreshDiv();
        }
      },
      error : function(xhr, ErrorStatus, error){
        console.log(status.error);
      }

    });
    return false;
  });



// создание теста
$(document).on("submit","#addExamFrm" , function(){
  $.post("query/addExamExe.php", $(this).serialize() , function(data){
    if(data.res == "noSelectedCourse")
   {
      Swal.fire(
          'Нет Группы',
          'Пожалуйста Выберите Группу',
          'error'
       )
    }
    if(data.res == "noSelectedTime")
   {
      Swal.fire(
          'Не Установлено Время',
          'Пожалуйста установите лимит времени',
          'error'
       )
    }
    if(data.res == "noDisplayLimit")
   {
      Swal.fire(
          'Нет Кол-ва вопросов',
          'Пожалуйста установите ограничение на отображение вопросов',
          'error'
       )
    }

     else if(data.res == "exist")
    {
      Swal.fire(
        'Уже Существует',
        data.examTitle.toUpperCase() + '<br>Already Exist',
        'error'
      )
    }
    else if(data.res == "success")
    {
      Swal.fire(
        'Готово!',
        data.examTitle.toUpperCase() + '<br>Тест Создан',
        'success'
      )
          $('#addExamFrm')[0].reset();
          $('#course_name').val("");
          refreshDiv();
    }
  },'json')
  return false;
});



// обновление теста
$(document).on("submit","#updateExamFrm" , function(){
  $.post("query/updateExamExe.php", $(this).serialize() , function(data){
    if(data.res == "success")
    {
      Swal.fire(
          'Готово!',
          data.msg + ' <br>Обновление завершено',
          'success'
       )
          refreshDiv();
    }
    else if(data.res == "failed")
    {
      Swal.fire(
        "Что-то пошло не так!",
         'Что-то пошло не так',
        'error'
      )
    }
   
  },'json')
  return false;
});

// обновление вопроса
$(document).on("submit","#updateQuestionFrm" , function(){
  $.post("query/updateQuestionExe.php", $(this).serialize() , function(data){
     if(data.res == "success")
     {
        Swal.fire(
            'Готово!',
            'Выбранный вопрос успешно обновлен!',
            'success'
          )
          refreshDiv();
     }
  },'json')
  return false;
});


// удаление вопроса
$(document).on("click", "#deleteQuestion", function(e){
    e.preventDefault();
    var id = $(this).data("id");
     $.ajax({
      type : "post",
      url : "query/deleteQuestionExe.php",
      dataType : "json",  
      data : {id:id},
      cache : false,
      success : function(data){
        if(data.res == "success")
        {
          Swal.fire(
            'Готово!',
            'Выбранный вопрос успешно удален',
            'success'
          )
          refreshDiv();
        }
      },
      error : function(xhr, ErrorStatus, error){
        console.log(status.error);
      }

    });
    
   

    return false;
  });


// Создание вопроса
$(document).on("submit","#addQuestionFrm" , function(){
  $.post("query/addQuestionExe.php", $(this).serialize() , function(data){
    if(data.res == "exist")
    {
      Swal.fire(
          'Уже Существуют',
          data.msg + ' вопрос <br>уже существуют в этом примере',
          'error'
       )
    }
    else if(data.res == "success")
    {
      Swal.fire(
        'Готово',
         data.msg + ' вопрос <br>успешно создан',
        'success'
      )
        $('#addQuestionFrm')[0].reset();
        refreshDiv();
    }
   
  },'json')
  return false;
});


// Добавление студента
$(document).on("submit","#addExamineeFrm" , function(){
  $.post("query/addExamineeExe.php", $(this).serialize() , function(data){
    if(data.res == "noGender")
    {
      Swal.fire(
          'Не выбран пол',
          'Пожалуйста выберите пол',
          'error'
       )
    }
    else if(data.res == "noCourse")
    {
      Swal.fire(
          'Нет Группы',
          'Пожалуйста выберите группу',
          'error'
       )
    }
    else if(data.res == "noLevel")
    {
      Swal.fire(
          'Нет Года',
          'Пожалуйста выберите год',
          'error'
       )
    }
    else if(data.res == "fullnameExist")
    {
      Swal.fire(
          'Полное имя Уже Существует',
          data.msg + ' Уже Существует',
          'error'
       )
    }
    else if(data.res == "emailExist")
    {
      Swal.fire(
          'Электронная Почта Уже Существует',
          data.msg + ' Уже Существует',
          'error'
       )
    }
    else if(data.res == "success")
    {
      Swal.fire(
          'Готово!',
          data.msg + ' успешно добавлен',
          'success'
       )
        refreshDiv();
        $('#addExamineeFrm')[0].reset();
    }
    else if(data.res == "failed")
    {
      Swal.fire(
          "Что-то пошло не так",
          '',
          'error'
       )
    }


    
  },'json')
  return false;
});



// Обновление студента
$(document).on("submit","#updateExamineeFrm" , function(){
  $.post("query/updateExamineeExe.php", $(this).serialize() , function(data){
     if(data.res == "success")
     {
        Swal.fire(
            'Готово!',
            data.exFullname + ' <br>успешно обновлен!',
            'success'
          )
          refreshDiv();
     }
  },'json')
  return false;
});


function refreshDiv()
{
  $('#tableList').load(document.URL +  ' #tableList');
  $('#refreshData').load(document.URL +  ' #refreshData');

}


