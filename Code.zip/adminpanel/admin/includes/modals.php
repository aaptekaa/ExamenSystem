<div class="modal fade" id="modalForAddCourse" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form class="refreshFrm" id="addCourseFrm" method="post">
     <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Создать Группу</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <div class="form-group">
            <label>Группа</label>
            <input type="" name="course_name" id="course_name" class="form-control" placeholder="Введите название" required="" autocomplete="off">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
        <button type="submit" class="btn btn-primary">Создать</button>
      </div>
    </div>
   </form>
  </div>
</div>

<div class="modal fade myModal" id="updateCourse-<?php echo $selCourseRow['cou_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog " role="document">
     <form class="refreshFrm" id="addCourseFrm" method="post" >
       <div class="modal-content myModal-content" >
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Обновить ( <?php echo $selCourseRow['cou_name']; ?> )</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="col-md-12">
            <div class="form-group">
              <label>Группа</label>
              <input type="" name="course_name" id="course_name" class="form-control" value="<?php echo $selCourseRow['cou_name']; ?>">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
          <button type="submit" class="btn btn-primary">Обновить</button>
        </div>
      </div>
     </form>
    </div>
  </div>


<div class="modal fade" id="modalForExam" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form class="refreshFrm" id="addExamFrm" method="post">
     <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Создать тест</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <div class="form-group">
            <label>Выберите Группу</label>
            <select class="form-control" name="courseSelected">
              <option value="0">Выбор Группы</option>
              <?php 
                $selCourse = $conn->query("SELECT * FROM course_tbl ORDER BY cou_id DESC");
                if($selCourse->rowCount() > 0)
                {
                  while ($selCourseRow = $selCourse->fetch(PDO::FETCH_ASSOC)) { ?>
                     <option value="<?php echo $selCourseRow['cou_id']; ?>"><?php echo $selCourseRow['cou_name']; ?></option>
                  <?php }
                }
                else
                { ?>
                  <option value="0">Группы не найдены</option>
                <?php }
               ?>
            </select>
          </div>

          <div class="form-group">
            <label>Установите Время</label>
            <select class="form-control" name="timeLimit" required="">
              <option value="0">Выбор Времени</option>
              <option value="10">10 Минут</option>
              <option value="20">20 Минут</option>
              <option value="30">30 Минут</option>
              <option value="40">40 Минут</option>
              <option value="50">50 Минут</option>
              <option value="60">60 Минут</option>
            </select>
          </div>

          <div class="form-group">
            <label>Ограничение на отображение вопросов</label>
            <input type="number" name="examQuestDipLimit" id="" class="form-control" placeholder="Ограничение на ввод вопроса для отображения">
          </div>

          <div class="form-group">
            <label>Название Теста</label>
            <input type="" name="examTitle" class="form-control" placeholder="Введите Название Теста" required="">
          </div>

          <div class="form-group">
            <label>Описание Теста</label>
            <textarea name="examDesc" class="form-control" rows="4" placeholder="Введите Описание Теста" required=""></textarea>
          </div>

        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
        <button type="submit" class="btn btn-primary">Создать</button>
      </div>
    </div>
   </form>
  </div>
</div>

<div class="modal fade" id="modalForAddExaminee" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form class="refreshFrm" id="addExamineeFrm" method="post">
     <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Добавить Студента</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <div class="form-group">
            <label>Имя</label>
            <input type="" name="fullname" id="fullname" class="form-control" placeholder="Введите Полное Имя" autocomplete="off" required="">
          </div>
          <div class="form-group">
            <label>Дата Рождения</label>
            <input type="date" name="bdate" id="bdate" class="form-control" placeholder="Введите Дату Рождения" autocomplete="off" >
          </div>
          <div class="form-group">
            <label>Пол</label>
            <select class="form-control" name="gender" id="gender">
              <option value="0">Выберите пол</option>
              <option value="male">Мужской</option>
              <option value="female">Женский</option>
            </select>
          </div>
          <div class="form-group">
            <label>Группа</label>
            <select class="form-control" name="course" id="course">
              <option value="0">Выберите Группу</option>
              <?php 
                $selCourse = $conn->query("SELECT * FROM course_tbl ORDER BY cou_id asc");
                while ($selCourseRow = $selCourse->fetch(PDO::FETCH_ASSOC)) { ?>
                  <option value="<?php echo $selCourseRow['cou_id']; ?>"><?php echo $selCourseRow['cou_name']; ?></option>
                <?php }
               ?>
            </select>
          </div>
          <div class="form-group">
            <label>Год</label>
            <select class="form-control" name="year_level" id="year_level">
              <option value="0">Выберите год</option>
              <option value="first year">Первый Год</option>
              <option value="second year">Второй Год</option>
              <option value="third year">Третий Год</option>
              <option value="fourth year">Четвертый Год</option>
            </select>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" id="email" class="form-control" placeholder="Введите Email" autocomplete="off" required="">
          </div>
          <div class="form-group">
            <label>Пароль</label>
            <input type="password" name="password" id="password" class="form-control" placeholder="Введите Пароль" autocomplete="off" required="">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
        <button type="submit" class="btn btn-primary">Добавить</button>
      </div>
    </div>
   </form>
  </div>
</div>



<!-- Modal For Add Question -->
<div class="modal fade" id="modalForAddQuestion" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form class="refreshFrm" id="addQuestionFrm" method="post">
     <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Создать вопрос для теста: <?php echo $selExamRow['ex_title']; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form class="refreshFrm" method="post" id="addQuestionFrm">
      <div class="modal-body">
        <div class="col-md-12">
          <div class="form-group">
            <label>Вопрос</label>
            <input type="hidden" name="examId" value="<?php echo $exId; ?>">
            <input type="" name="question" id="course_name" class="form-control" placeholder="Введите Вопрос" autocomplete="off">
          </div>

          <fieldset>
            <legend>Введите Варианты Ответов</legend>
            <div class="form-group">
                <label>Вариант A</label>
                <input type="" name="choice_A" id="choice_A" class="form-control" placeholder="Введите вариант A" autocomplete="off">
            </div>

            <div class="form-group">
                <label>Вариант B</label>
                <input type="" name="choice_B" id="choice_B" class="form-control" placeholder="Введите вариант B" autocomplete="off">
            </div>

            <div class="form-group">
                <label>Вариант C</label>
                <input type="" name="choice_C" id="choice_C" class="form-control" placeholder="Введите вариант C" autocomplete="off">
            </div>

            <div class="form-group">
                <label>Вариант D</label>
                <input type="" name="choice_D" id="choice_D" class="form-control" placeholder="Введите вариант D" autocomplete="off">
            </div>

            <div class="form-group">
                <label>Правильный ответ</label>
                <input type="" name="correctAnswer" id="" class="form-control" placeholder="Введите правильный вариант" autocomplete="off">
            </div>
          </fieldset>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
        <button type="submit" class="btn btn-primary">Добавить</button>
      </div>
      </form>
    </div>
   </form>
  </div>
</div>